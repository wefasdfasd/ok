# Rickroll
A website with Never Gonna Give You Up that can be used to rickroll your friends.

Find it here: https://rebrand.ly/r1ckr0l13r
